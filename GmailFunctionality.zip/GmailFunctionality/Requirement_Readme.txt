I am writing this Requirement document behalf of TAYLOR corporation: Test Demo

# Project Assessment:
This is the requirement document of Demo project. To deliver of an automated test for email sending functionality via Gmail.

The test is supposed to:
- Login to Gmail
- Compose an email with unique subject (Demo), body (This is a test mail for Demo purpose), and attachment (Requirement_Readme)
- Send the email to the same account which was used to login (from and to addresses would be the same)

# Tasks:
1. Create Test case in Gherkin
2. Convert Test cases into Cucumber Automation script in JAVA for the following scenarios:
- Login to Gmail account
- Compose an Email with Subject, Body and a Attachment
- Send Email (where To and Form should be same)

PLEASE NOTE THAT ALL THE TASKS LISTED ABOVE ARE MANDATORY. We'll be evaluating your submission on the following parameters:
- Code quality and best practices
- Implementation of new test cases

# Prerequisites:
- ChromeDriver, JDK 8+
- Any IDE

# Development Environment:
- Develop GmailTest.java to point to ChromeDriver's path on your system
- On any terminal, move to the project's root folder

# How to deliver:
1. Make sure that the tests are passing, there are no errors, and any new dependencies are specified.
2. Zip your project folder and name it 'GmailFunctionality.zip'.
3. Store your file in a shared location (gitHub) where Taylor Team can access and download it for evaluation. 




