package pageObjects;

import java.io.IOException;

import org.junit.Assert;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Gmail_Functionality extends BasePage {

	public @FindBy(xpath = "//input[@id='identifierId']") WebElement textfield_userId;
	public @FindBy(xpath = "//div[@id='identifierNext']//content[@class='CwaK9']") WebElement next_field;
	public @FindBy(xpath = "//input[@name='password']") WebElement textfield_password;
	public @FindBy(id = "passwordNext") WebElement login_button;
	public @FindBy(xpath = "//textarea[@name='to' and @role='combobox']") WebElement recipient_field;
	public @FindBy(xpath = "//div[@class='T-I J-J5-Ji T-I-KE L3']") WebElement compose_field;
	public @FindBy(xpath = "//div[@aria-label='New Message' and @role='region']") WebElement compose_window;
	public @FindBy(xpath = "//input[@name='subjectbox']") WebElement subject_field;
	public @FindBy(xpath = "//div[@aria-label='Message Body' and @role='textbox']") WebElement body_field;
	public @FindBy(xpath = "//div[@role='button' and text()='Send']") WebElement send_now;
	public @FindBy(xpath = "//span[@class='bAq' and text()='Message Sent.']") WebElement messageIsSent;
	
		
	public Gmail_Functionality() throws IOException {
		super();
	}
	
	public Gmail_Functionality getLoginPage(String url) throws IOException {
		getDriver().get(url);
		return new Gmail_Functionality();
	}
	
	public Gmail_Functionality enterUserId(String username) throws Exception {
		sendKeysToWebElement(textfield_userId, username);
		return new Gmail_Functionality();
	}
	
	public Gmail_Functionality goToNextField() throws Exception {
		waitAndClickElement(next_field);
		return new Gmail_Functionality();
	}
	
	public Gmail_Functionality enterPassword(String password) throws Exception {
		sendKeysToWebElement(textfield_password, password);
		return new Gmail_Functionality();
	}
	
	public Gmail_Functionality clickOnLogin() throws Exception {
		waitAndClickElement(login_button);
		Thread.sleep(8000);
		getDriver().get("https://mail.google.com/mail/#inbox");
		return new Gmail_Functionality();
	}
	
	public Gmail_Functionality verifyLogin() throws Exception {
		WaitUntilWebElementIsVisible(compose_field);
		Assert.assertEquals("compose", compose_field.getText().toLowerCase().replaceAll("[ ()0-9]", ""));
		return new Gmail_Functionality();
	}
	
	public Gmail_Functionality clickOnCompose() throws Exception {
		waitAndClickElement(compose_field);
		return new Gmail_Functionality();
	}
	
	public Gmail_Functionality setRecipient(String email) throws Exception {
		sendKeysToWebElement(recipient_field, email);
		return new Gmail_Functionality();
	}
	
	public Gmail_Functionality setSubject(String sub) throws Exception {
		sendKeysToWebElement(subject_field, sub);
		return new Gmail_Functionality();
	}
	
	public Gmail_Functionality setBodyText(String text) throws Exception {
		sendKeysToWebElement(body_field, text);
		return new Gmail_Functionality();
	}
	
	public Gmail_Functionality sendNow() throws Exception {
		waitAndClickElement(send_now);
		return new Gmail_Functionality();
	}
	
	public Gmail_Functionality composeVisible() throws Exception {
		Thread.sleep(5000);
		WaitUntilWebElementIsVisible(send_now);
		Assert.assertEquals("send", send_now.getText().toLowerCase().replaceAll("[ ()0-9]", ""));
		return new Gmail_Functionality();
	}
	
	public Gmail_Functionality sentConfirmation() throws Exception {
		Assert.assertTrue(true);
		return new Gmail_Functionality();
	}
	
}
