package stepDefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import utils.DriverFactory;

public class LoginSteps extends DriverFactory {
	
@Given("^User is on Gmail Sign in page$")
public void user_is_on_Gmail_Sign_in_page() throws Throwable {
	getDriver().get("https://accounts.google.com/signin/v2/identifier?flowName=GlifWebSignIn&flowEntry=ServiceLogin");
}

@Given("^User entered a valid \"([^\"]*)\" Gmail ID$")
public void user_entered_a_valid_Gmail_ID(String username) throws Throwable {
	loginPage.enterUserId(username);
}

@Then("^User clicked next/hit enter from keyboard$")
public void user_clicked_next_hit_enter_from_keyboard() throws Throwable {
	loginPage.goToNextField();
}

@Then("^User entered a valid \"([^\"]*)\" Password$")
public void user_entered_a_valid_Password(String password) throws Throwable {
	loginPage.enterPassword(password);
}

@When("^User Click next/hit enter from keyboard$")
public void user_Click_next_hit_enter_from_keyboard() throws Throwable {
	loginPage.clickOnLogin();
}

@Then("^User should be taken to the Gmail Account page$")
public void user_should_be_taken_to_the_Gmail_Account_page() throws Throwable {
	loginPage.verifyLogin();
}

//Scenario 2
@Then("^clicked the compose button$")
public void clicked_the_compose_button() throws Throwable {
	loginPage.clickOnCompose();
}

@Then("^the New Message Pop up modal opens$")
public void the_New_Message_Pop_up_modal_opens() throws Throwable {
	loginPage.composeVisible();
}

@Then("^enter Recipient \"([^\"]*)\" email address$")
public void enter_Recipient_email_address(String email) throws Throwable {
	loginPage.setRecipient(email);
}

@Then("^enter a Subject \"([^\"]*)\" line$")
public void enter_a_Subject_line(String sub) throws Throwable {
	loginPage.setSubject(sub);
}

@Then("^Compose a email Body \"([^\"]*)\"$")
public void compose_a_email_Body(String text) throws Throwable {
	loginPage.setBodyText(text);
}

//Scenario 3

@When("^Clicked on Send button$")
public void clicked_on_Send_button() throws Throwable {
	loginPage.sendNow();
	Thread.sleep(5000);
}

@Then("^a delivery confirmation message appears$")
public void a_delivery_confirmation_message_appears() throws Throwable {
	loginPage.sentConfirmation();

}



	
}
